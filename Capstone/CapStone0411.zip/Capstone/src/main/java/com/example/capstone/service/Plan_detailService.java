package com.example.capstone.service;


import org.springframework.stereotype.Service;

@Service
public class Plan_detailService {
}
