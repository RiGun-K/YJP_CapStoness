package com.example.capstone.dto.Board;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BoardDTO {

    private String mid;
    private String title;
    private String content;



}
