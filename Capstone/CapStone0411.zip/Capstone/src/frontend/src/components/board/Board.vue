<template>

  <div id="wrapper">
    <div id="content">
    <h1>{{ msg }}</h1>
    <h1>게시글 작성</h1>
      <button class="pay-infoter-now" @click="read">글쓰기</button>
    <h1>게시글 리스트</h1>
      <button class="pay-infoter-now" @click="list">글쓰기</button>


  </div>
  </div>
</template>

<script>
export default {
  name: "Board",
  props: {
    msg: String
  },

  methods: {
    list() {
      this.$router.push({
        path: 'Read'
      })
    },
    read() {
      this.$router.push({
        path: 'Create'
      })
    }
  }
}
</script>

<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
body {
  margin: 0;
  height: 100%;
  background-color: #E6E6FA;
}
#wrapper {
  position: relative;
  height: 100%;
}
#content {
  position: absolute;
  left: 50%;
  transform: translate(-50%);
  width: 460px;
}
#btnJoin {
  width: 45%;
  margin-left: 4%;
  padding: 21px 0 17px;
  border: 0;
  cursor: pointer;
  color: white;
  background-color: #52a3ef;
  font-size: 20px;
  font-weight: 400;
}
.infoterNow h5 button{
  margin: 0% 2%;
}
.pay-infoter-now{
  margin-left: 27%;
}
.infoter-now-info-check{
  margin: 3% 30%;
  padding: 1.5%;
}
.cancel-infoter-now{
  margin-left: 5%;
}
</style>