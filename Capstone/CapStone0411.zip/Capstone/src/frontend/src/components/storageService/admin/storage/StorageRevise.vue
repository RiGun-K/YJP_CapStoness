<template>
<div>
  <h1>revise - 수정</h1>
</div>
</template>

<script>

export default {
  name: "StorageRevise",
  components: {

  }

}
</script>

<style scoped>

</style>