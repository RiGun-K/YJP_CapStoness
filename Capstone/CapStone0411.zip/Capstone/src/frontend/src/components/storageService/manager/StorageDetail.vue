<template>

  <!--  관리하는 보관함 보기 -->
  <div v-if="managerCheck">
    <div class="storage">
      보관소 이름:{{name}}
      <div class="storage-view">
        <div class="storage-box" v-for="(storage,index) in storageBox" :key="index" @click="modalViewChk(storage.storageBoxCode)">
            <div>
              <ul>
                <li>보관함 이름: {{ storage.storageBoxName }}</li>
                <li>보관함 상태:<p v-if="storage.storageBoxState == '0'">사용안함</p>
                  <p v-else-if="storage.storageBoxState == '1' ">사용중</p>
                  <p v-else-if="storage.storageBoxState == '2' ">결제완료</p>
                </li>
              </ul>
            </div>
        </div>
      </div>
    </div>
  </div>

<!-- 모달-->
  <div v-if="modalView">
    <button @click="modalView = false">X</button>
    <div>
      <BoxModalDetail :boxCode="boxCode"></BoxModalDetail>
    </div>
  </div>
</template>

<script>
import axios from "axios";
import store from "@/store"
import BoxModalDetail from "@/components/storageService/manager/BoxModalDetail.vue";
export default {
  name: "StorageDetail",
  components:{
    BoxModalDetail
  },
  data() {
    return {
      managerId: '',
      managerCheck:false,
      storageBox:[],
      name:'',
      modalView:false,
      modal: false,
      message: '',
      boxCode: ''
    }
  },
  mounted() {
    this.managerId = store.getters.getLoginState.loginState
    axios.get('/api/managerCheck/'+this.managerId)
        .then(res=>{
          console.log(res)
          if(res.data.result=='ok'){
            console.log('확인')
            this.managerCheck = !this.managerCheck

            if(this.managerCheck){
              axios.get('/api/getManagerStorage/'+this.managerId)
                  .then(res=>{
                    console.log(res.data)
                    this.storageBox = res.data
                    this.name = this.storageBox[1].storageCode.storageName
                    this.managerId = ''
                  })
                  .catch(err=>{
                    console.log(err)
                  })
            }
          }else {
            console.log("안돼")
          }
        })
  },
  methods:{
    modalViewChk(storage){
      // console.log('post storageCode')
      // console.log(storage)
      this.boxCode = storage
      if(!this.modalView){
        this.modalView = !this.modalView
      }

      // this.$router.push({name:'boxDetail', params:{storage:storage}})
    },
    inputMamager() {

    },
    openModal() {
      this.modal = true
    },
    closeModal() {
      this.modal = false
    },
    doSend() {
      if (this.message.length > 0) {
        alert(this.message)
        this.message = ''
        this.closeModal()
      } else {
        alert('메시지를 입력해주세요.')
      }
    }
  }
}
</script>

<style lang="css" scoped>
.storage-box {
  border: solid 3px #DAA520;
  border-radius: 10px;
  width: 200px;

}

.storage-view {
  border: solid 1px #2c3e50;
  display: -webkit-flex;
  display: flex;
}

.storage {
  border: solid 3px #42b983;
}



</style>