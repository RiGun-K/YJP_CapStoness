<template>
  선호도입니다
</template>

<script>
export default {
  name: "Horby"
}
</script>

<style scoped>

</style>
