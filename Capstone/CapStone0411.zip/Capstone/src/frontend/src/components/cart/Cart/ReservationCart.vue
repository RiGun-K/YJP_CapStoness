<template>
  <div class="reservation-cart">

  </div>
</template>

<script>
export default {
  name: 'ReservationCart'
}
</script>

<style scoped>

</style>
