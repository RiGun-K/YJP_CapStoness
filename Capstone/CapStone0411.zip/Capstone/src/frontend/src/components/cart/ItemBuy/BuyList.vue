<template>
  <Sidebar />
  <div :style="{ 'margin-left': sidebarWidth }">
    <router-view />
  </div>
  <div class="ItemBuy">
    <h2>Item Buy</h2>
      <br>
      <table class="table table-striped">
        <thead>
        <tr>
          <th>메뉴명</th>
          <th>분류</th>
          <th>가격</th>
          <th>설명</th>
        </tr>
        </thead>
        <tbody>
        <tr v-for="product in list"
            :key="product.id"
            :item="product" @click="toDetail(product)" style="cursor:pointer;">

          <td>{{ product.menuname }}</td>
          <td>{{ product.kindid.kindname }}</td>
          <td>{{ product.price }}</td>
          <td>{{ product.ex }}</td>
        </tr>
        <!-- PathVariable 을 위해서는 router-link 작성 -->
        <!--      <router-link :to="{name: 'productDetail', params: { menuid:product.menuid }}"></router-link>-->
        </tbody>
      </table>

  <!--    <button><router-link class="nav-link" to="/itemBuy/buyNow">Buy Now</router-link></button>-->
<!--    <button><router-link class="nav-link" to="/itemBuy/buyNow">Add to Cart</router-link></button>-->
  </div>
</template>

<script>
import axios from 'axios'

import Sidebar from '@/components/cart/Sidebar/Sidebar'
import {sidebarWidth} from '@/components/cart/Sidebar/state'
import ProductList from "@/components/product/ProductList";
// import { reactive } from 'vue'

export default {
  name: 'ItemBuy',
  components: { Sidebar },
  return: {
    sidebarWidth, ProductList
  },
  created() {
    this.goData()
  },
  data() {
    return {
      selected: false,
      list: [],
      product: '',
    }
  },
  methods: {
    goData() {
      axios.get('http://localhost:9002/api/product_list')
          .then((res) => {
            console.log(res.data);
            this.list = res.data;
          })
          .catch(e => {
            console.log(e)
          })
    },
    // path로 받기
    toDetail(product){
      this.$router.push({
        path: `/itemBuy/buyList/${product.menuid}`
      })
    }

  }
}

</script>

<style scoped>
.ItemBuy{
  width: 100%;
  height: 100%;
  margin-top: 3%;
}
.ItemBuy button{
  margin: 5%;
}
</style>
