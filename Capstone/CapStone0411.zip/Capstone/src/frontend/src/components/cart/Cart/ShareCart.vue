<template>
  <div class="share-cart">

  </div>
</template>

<script>
export default {
  name: 'ShareCart'
}
</script>

<style scoped>

</style>
