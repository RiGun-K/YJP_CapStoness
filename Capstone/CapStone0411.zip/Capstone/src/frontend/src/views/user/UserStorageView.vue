<template>

  <p>보관소 리스트 페이지</p>
  <div class="storage-get">
    <div v-for="(storage,index) in storageList" :key="index" @click="GetStorageDetail(storage.storageCode)">
      <div>
        이름:{{ storage.storageName }}
        주소:{{ storage.storageAddress }}
      </div>
    </div>
  </div>
  <div v-if="check">
    <div class="storage">
      보관소 이름:{{ name }}

      <button @click="askBox(this.memberId, this.boxList[1].storageCode.storageCode)">신청</button>
      <p @click="closeDetail">X</p>
      <div class="storage-view">

          <div class="storage-box" v-for="(box,index) in boxList" :key="index">
            <ul>
              <li>보관함 이름: {{ box.storageBoxName }}</li>
              <li>보관함 상태:<p v-if="box.storageBoxState == '0'">사용가능</p>
                <p v-else-if="box.storageBoxState == '1' ">사용불가능</p>
              </li>
            </ul>
          </div>
      </div>
    </div>
  </div>

</template>

<script>
import axios from "axios";
import store from "@/store";

export default {
  name: "UserStorageView",
  components: {},
  created() {
    axios.get('/api/getStorage')
        .then((res) => {
          console.log(res)
          console.log(res.data)
          this.storageList = res.data

          console.log('ALL this.storageList')
          console.log(this.storageList)
        })
        .catch((error) => {
          console.log(error)
        })
  },
  mounted() {
    this.memberId = store.getters.getLoginState.loginState
  },
  data() {
    return {
      storageList: [],
      check: false,
      boxList: [],
      name: '',
      memberId:''
    }
  },
  methods: {

    GetStorageDetail(storageCode) {
      this.detailCheck()
      axios.get('/api/storageView/' + storageCode)
          .then((resp) => {
            console.log(resp.data)
            this.boxList = resp.data
            this.name = this.boxList[0].storageCode.storageName
          })
          .catch((err) => {
            console.log(err)
          })
    },
    detailCheck() {
      if (!this.check) {
        this.check = !this.check
      }
    },
    closeDetail() {
      if (this.check) {
        this.check = !this.check
      }
    },
    askBox(memberId, storageCode){
      console.log('보관소 코드')
      console.log(storageCode)
      this.$router.push({name:'userStorageDetail', params:{storageCode:storageCode, memberId:memberId}})
    }

  }

}
</script>

<style scoped>
.storage-box {
  border: solid 3px #DAA520;
  border-radius: 10px;
  width: 200px;

}

.storage-view {
  border: solid 1px #2c3e50;
  display: -webkit-flex;
  display: flex;
}

.storage {
  border: solid 3px #42b983;
}
</style>