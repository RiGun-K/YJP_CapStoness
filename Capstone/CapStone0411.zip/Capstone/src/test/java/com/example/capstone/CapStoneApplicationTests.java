package com.example.capstone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CapStoneApplicationTests {

    @Test
    void contextLoads() {
    }

}
